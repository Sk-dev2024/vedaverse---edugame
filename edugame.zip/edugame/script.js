// Simple login form logic (this will later connect to MySQL backend)
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    // Backend integration here (for now, simple login logic)
    if (username === "student" && password === "12345") {
        window.location.href = "home.html"; // Redirect to home page
    } else {
        alert("Invalid credentials");
    }
});
