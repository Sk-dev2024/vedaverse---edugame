<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

include 'db_connection.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $questions = $_POST['questions'];
    $answers = $_POST['answers'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Results</title>
    <link rel="stylesheet" href="submit_quiz.css"> <!-- Link to your CSS file -->
</head>
<body>

<div class="result-container">
    <h1>Quiz Results</h1>
    <?php
    foreach ($questions as $question_id) {
        // Fetch the correct answer from the database
        $query = "SELECT answer FROM questions WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $question_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $correct_answer = $result->fetch_assoc()['answer'];

        // Check the user's answer
        if (isset($answers[$question_id]) && trim($answers[$question_id]) === $correct_answer) {
            echo "<div class='question correct'>Question $question_id: Correct!</div>";
        } else {
            echo "<div class='question wrong'>Question $question_id: Wrong! The correct answer was: $correct_answer</div>";
        }
    }
    ?>
    <button onclick="window.history.back();">Go Back</button>
</div>

</body>
</html>

<?php
}
?>
