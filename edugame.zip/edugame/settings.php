<?php
include('db_connection.php');
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_password = $_POST['password'];
    $email_pref = $_POST['email_pref'];

    // Update user settings in the database
    $query = "UPDATE users SET password='$new_password', email_pref='$email_pref' WHERE id='$user_id'";
    mysqli_query($conn, $query);
    echo "<div class='success-message'>Settings updated successfully!</div>"; // Success message
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings - EduGame</title>
    <link rel="stylesheet" href="settings.css"> <!-- Link to the CSS file -->
</head>
<body>
    <div class="settings-container">
        <h1>Account Settings</h1>
        <form method="POST">
            <label for="password">New Password</label>
            <input type="password" name="password" required>

            <label for="email_pref">Email Notifications</label>
            <select name="email_pref">
                <option value="1">Enable</option>
                <option value="0">Disable</option>
            </select>

            <button type="submit">Update Settings</button>
        </form>
    </div>
</body>
</html>
