<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

include 'db_connection.php'; // Include your database connection

// Get the quiz ID from the URL
$quiz_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch questions for the selected quiz
$query = "SELECT * FROM questions WHERE quiz_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$result = $stmt->get_result();

// Check for query execution
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz - EduGame</title>
    <link rel="stylesheet" href="quiz.css">
</head>
<body>
   
    <div class="main-content">
        <h1>Quiz Questions</h1>
        <form action="submit_quiz.php" method="POST">
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div>
                    <p><?php echo htmlspecialchars($row['question_text']); ?></p>
                    <input type="hidden" name="questions[]" value="<?php echo $row['id']; ?>">
                    <input type="text" name="answers[<?php echo $row['id']; ?>]" placeholder="Your answer">
                </div>
            <?php endwhile; ?>
            <button type="submit">Submit Answers</button>
        </form>
    </div>
</body>
</html>
