<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Include database connection
include 'db_connection.php';

// Fetch quizzes from the database
$query = "SELECT * FROM quizzes";
$result = mysqli_query($conn, $query);

// Check for query execution
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quizzes - EduGame</title>
    <link rel="stylesheet" href="quizes.css">
</head>
<body>
   
    <div class="main-content">
        <h1>Available Quizzes</h1>
        <ul>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <li><a href="quiz.php?id=<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['quiz_name']); ?></a></li>
            <?php endwhile; ?>
        </ul>
    </div>
</body>
</html>
