<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - EduGame</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Forgot Password</h2>
            <form action="forgot_password_process.php" method="POST">
                <div class="input-group">
                    <input type="email" name="email" placeholder="Enter your email" required>
                </div>
                <button type="submit" class="btn-login">Reset Password</button>
                <div class="options">
                    <a href="index.php">Back to Login</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
