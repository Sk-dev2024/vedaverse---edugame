<?php
include('db.php');

// Fetch leaderboard data from database
$query = "SELECT username, points FROM users ORDER BY points DESC LIMIT 10";
$result = mysqli_query($conn, $query);
?>

<div class="main-content">
    <h1>Leaderboard</h1>
    <table>
        <tr>
            <th>Rank</th>
            <th>Username</th>
            <th>Points</th>
        </tr>
        <?php $rank = 1; while ($user = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $rank++; ?></td>
            <td><?php echo $user['username']; ?></td>
            <td><?php echo $user['points']; ?></td>
        </tr>
        <?php } ?>
    </table>
</div>
